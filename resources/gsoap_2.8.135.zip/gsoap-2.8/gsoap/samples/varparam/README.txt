Variable polymorphic parameter passing example.

The SOAP specification supports variable parameter lists. In addition,
parameters can be polymorphic. Both features are demonstrated in this example
in C and C++.

